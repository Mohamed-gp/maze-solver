"use client"

import * as React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { cva } from "class-variance-authority"

import { cn } from "@/lib/utils"

const sidebarVariants = cva("flex h-full flex-col overflow-hidden border-r bg-background text-foreground", {
  variants: {
    collapsible: {
      none: "",
      icon: "data-[collapsed=true]:w-[--sidebar-icon-width] data-[collapsed=true]:group-[]/sidebar:w-[--sidebar-icon-width]",
      full: "data-[collapsed=true]:w-0 data-[collapsed=true]:group-[]/sidebar:w-0",
    },
  },
  defaultVariants: {
    collapsible: "none",
  },
})

const SidebarContext = createContext<{
  collapsed: boolean
  setCollapsed: React.Dispatch<React.SetStateAction<boolean>>
  isMobile: boolean
}>({
  collapsed: false,
  setCollapsed: () => {},
  isMobile: false,
})

export function useSidebar() {
  return useContext(SidebarContext)
}

export interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {
  collapsible?: "none" | "icon" | "full"
  defaultCollapsed?: boolean
  iconWidth?: number
}

export function SidebarProvider({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  return (
    <SidebarContext.Provider value={{ collapsed, setCollapsed, isMobile }}>
      <div className="group/sidebar flex h-full w-full">{children}</div>
    </SidebarContext.Provider>
  )
}

export function Sidebar({
  className,
  collapsible = "none",
  defaultCollapsed = false,
  iconWidth = 48,
  ...props
}: SidebarProps) {
  const { collapsed, setCollapsed } = useSidebar()

  React.useEffect(() => {
    setCollapsed(defaultCollapsed)
  }, [defaultCollapsed, setCollapsed])

  React.useEffect(() => {
    document.documentElement.style.setProperty("--sidebar-icon-width", `${iconWidth}px`)
  }, [iconWidth])

  return <div data-collapsed={collapsed} className={cn(sidebarVariants({ collapsible }), className)} {...props} />
}

export function SidebarTrigger() {
  const { collapsed, setCollapsed } = useSidebar()

  return (
    <button
      type="button"
      className="inline-flex h-6 w-6 items-center justify-center rounded-md text-muted-foreground hover:text-foreground"
      onClick={() => setCollapsed(!collapsed)}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-4 w-4"
      >
        <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
        <path d="M9 3v18" />
      </svg>
      <span className="sr-only">Toggle Sidebar</span>
    </button>
  )
}

export function SidebarHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("px-2 py-2", className)} {...props} />
}

export function SidebarContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex-1 overflow-auto px-2 py-2", className)} {...props} />
}

export function SidebarFooter({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("mt-auto px-2 py-2", className)} {...props} />
}

export function SidebarGroup({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("py-2", className)} {...props} />
}

export function SidebarGroupLabel({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("px-2 py-1.5 text-xs font-medium text-muted-foreground", className)} {...props} />
}

export function SidebarGroupContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("px-1 py-0.5", className)} {...props} />
}

export function SidebarMenu({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("grid gap-1", className)} {...props} />
}

export function SidebarMenuItem({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("relative flex items-center gap-1", className)} {...props} />
}

export interface SidebarMenuButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isActive?: boolean
  size?: "default" | "sm" | "lg"
  asChild?: boolean
}

export const SidebarMenuButton = React.forwardRef<HTMLButtonElement, SidebarMenuButtonProps>(
  ({ className, children, isActive = false, size = "default", asChild = false, ...props }, ref) => {
    const { collapsed } = useSidebar()
    const Comp = asChild ? React.Fragment : "button"
    const childProps = asChild
      ? { className: cn("contents", className) }
      : {
          ref,
          className: cn(
            "group relative flex w-full items-center gap-2 rounded-md px-2 text-left text-sm font-medium ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
            size === "default" && "h-9",
            size === "sm" && "h-8",
            size === "lg" && "h-10",
            isActive
              ? "bg-accent text-accent-foreground hover:bg-accent/80"
              : "hover:bg-accent/50 hover:text-accent-foreground",
            className,
          ),
          ...props,
        }

    return (
      <Comp {...childProps}>
        {asChild ? (
          children
        ) : (
          <>
            {children}
            {collapsed && (
              <span className="sr-only group-hover:not-sr-only group-hover:fixed group-hover:left-[--sidebar-icon-width] group-hover:z-50 group-hover:ml-2 group-hover:rounded-md group-hover:bg-accent group-hover:px-2 group-hover:py-1.5 group-hover:text-accent-foreground group-hover:shadow-md">
                {typeof children === "string"
                  ? children
                  : Array.isArray(children) && React.isValidElement(children[1]) && children[1].props.children}
              </span>
            )}
          </>
        )}
      </Comp>
    )
  },
)
SidebarMenuButton.displayName = "SidebarMenuButton"

export interface SidebarMenuActionProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  showOnHover?: boolean
}

export const SidebarMenuAction = React.forwardRef<HTMLButtonElement, SidebarMenuActionProps>(
  ({ className, showOnHover = false, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "absolute right-2 flex h-6 w-6 items-center justify-center rounded-md",
          showOnHover && "opacity-0 group-hover:opacity-100",
          className,
        )}
        {...props}
      />
    )
  },
)
SidebarMenuAction.displayName = "SidebarMenuAction"

export function SidebarMenuBadge({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "ml-auto flex h-6 items-center justify-center rounded-md bg-primary/10 px-1.5 text-xs font-medium text-primary",
        className,
      )}
      {...props}
    />
  )
}

export function SidebarMenuSub({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("ml-4 grid gap-1 border-l pl-2 pt-1", className)} {...props} />
}

export function SidebarMenuSubItem({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("relative flex items-center gap-1", className)} {...props} />
}

export interface SidebarMenuSubButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isActive?: boolean
  asChild?: boolean
}

export const SidebarMenuSubButton = React.forwardRef<HTMLButtonElement, SidebarMenuSubButtonProps>(
  ({ className, children, isActive = false, asChild = false, ...props }, ref) => {
    const { collapsed } = useSidebar()
    const Comp = asChild ? React.Fragment : "button"
    const childProps = asChild
      ? { className: cn("contents", className) }
      : {
          ref,
          className: cn(
            "group relative flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm font-medium ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
            isActive
              ? "bg-accent text-accent-foreground hover:bg-accent/80"
              : "hover:bg-accent/50 hover:text-accent-foreground",
            className,
          ),
          ...props,
        }

    return (
      <Comp {...childProps}>
        {asChild ? (
          children
        ) : (
          <>
            {children}
            {collapsed && (
              <span className="sr-only group-hover:not-sr-only group-hover:fixed group-hover:left-[--sidebar-icon-width] group-hover:z-50 group-hover:ml-2 group-hover:rounded-md group-hover:bg-accent group-hover:px-2 group-hover:py-1.5 group-hover:text-accent-foreground group-hover:shadow-md">
                {typeof children === "string"
                  ? children
                  : Array.isArray(children) && React.isValidElement(children[1]) && children[1].props.children}
              </span>
            )}
          </>
        )}
      </Comp>
    )
  },
)
SidebarMenuSubButton.displayName = "SidebarMenuSubButton"

export function SidebarSeparator({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("mx-2 my-2 h-px bg-border", className)} {...props} />
}

export function SidebarRail() {
  const { collapsed, setCollapsed } = useSidebar()

  return (
    <div
      className="absolute right-0 top-0 h-full w-px translate-x-1/2 cursor-col-resize bg-border"
      onMouseDown={(e) => {
        e.preventDefault()
        const startX = e.clientX
        const handleMouseMove = (e: MouseEvent) => {
          const diffX = e.clientX - startX
          if (Math.abs(diffX) > 50) {
            setCollapsed(diffX > 0)
            document.removeEventListener("mousemove", handleMouseMove)
            document.removeEventListener("mouseup", handleMouseUp)
          }
        }
        const handleMouseUp = () => {
          document.removeEventListener("mousemove", handleMouseMove)
          document.removeEventListener("mouseup", handleMouseUp)
        }
        document.addEventListener("mousemove", handleMouseMove)
        document.addEventListener("mouseup", handleMouseUp)
      }}
    />
  )
}

export function SidebarInset({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-1 flex-col overflow-hidden", className)} {...props} />
}

